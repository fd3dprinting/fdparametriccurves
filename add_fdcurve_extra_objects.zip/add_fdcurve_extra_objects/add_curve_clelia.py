# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

bl_info = {
    "name": "Clelia Curve",
    "description": "Add Clelia Curves",
    "author": "testscreenings, fluiddesigner",
    "version": (0, 1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Add > Curve",
    "warning": "",
    "wiki_url": "https://www.fluiddesigner.co.uk/",
    "category": "Add Curve"
}


##------------------------------------------------------------
#### import modules
import bpy
from bpy.props import *
from math import sin, cos, pi
from bpy_extras.object_utils import AddObjectHelper, object_data_add


########################################################################
####################### Clelia Definitions ###############################
########################################################################
def Clelia(self):
    p = self.clelia_p
    q = self.clelia_q
    w = self.clelia_w
    res = self.clelia_res
    h = self.clelia_h
    u = self.clelia_u
    v = self.clelia_v
    rounds = self.clelia_rounds

    newPoints = []
    angle = 2*rounds
    step = angle/(res-1)
    scale = h
    height = w

    for i in range(res-1):
        t = ( i*step*pi)

        x = scale * cos(p * t * u) * cos(t * u)
        y = scale * cos(p * t * u) * sin(t * u)
        z = w * sin(p * t * u)

        newPoints.extend([x,y,z,1])

    return newPoints


##------------------------------------------------------------
# Main Function
def create_clelia_knot(self, context):
    verts = Clelia(self)

    curve_data = bpy.data.curves.new(name='Clelia', type='CURVE')
    spline = curve_data.splines.new(type='NURBS')
    spline.points.add(int(len(verts)*0.25 - 1))
    spline.points.foreach_set('co', verts)
    spline.use_endpoint_u = True
    spline.use_cyclic_u = True
    spline.order_u = 4
    curve_data.dimensions = '3D'

    if self.geo_surf:
        curve_data.bevel_depth = self.geo_bDepth
        curve_data.bevel_resolution = self.geo_bRes
        curve_data.fill_mode = 'FULL'
        curve_data.extrude = self.geo_extrude
        #curve_data.offset = self.geo_width # removed, somehow screws things up all of a sudden
        curve_data.resolution_u = self.geo_res

    new_obj = object_data_add(context, curve_data, operator=self)


class CLELIA_OT_clelia(bpy.types.Operator, AddObjectHelper):
    """"""
    bl_idname = "curve.clelia"
    bl_label = "Clelia Curves"
    bl_options = {'REGISTER', 'UNDO', 'PRESET'}
    bl_description = "adds many types of clelia curves"

    #### general options
    options_plus : BoolProperty(name="plus options",
                default=False,
                description="Show more options (the plus part)")

    #### GEO Options
    geo_surf : BoolProperty(name="Surface",
                default=True)
    geo_bDepth : FloatProperty(name="bevel",
                default=0.50,
                min=0, soft_min=0)
    geo_bRes : IntProperty(name="bevel res",
                default=2,
                min=0, soft_min=0,
                max=4, soft_max=4)
    geo_extrude : FloatProperty(name="extrude",
                default=0.0,
                min=0, soft_min=0)
    geo_res : IntProperty(name="resolution",
                default=30,
                min=1, soft_min=1)


    #### Parameters
    clelia_res : IntProperty(name="Resoulution",
                default=90,
                min=3, soft_min=3,
                description='Resolution, Number of controlverticies')
    clelia_p : IntProperty(name="p",
                default=3,
                min=1, soft_min=1,
                #max=1, soft_max=1,
                description="p")
    clelia_q : IntProperty(name="q",
                default=3,
                min=1, soft_min=1,
                #max=1, soft_max=1,
                description="q")
    clelia_w : FloatProperty(name="Height",
                default=5.0,
                #min=0, soft_min=0,
                #max=1, soft_max=1,
                description="Height in Z")
    clelia_h : FloatProperty(name="Scale",
                default=5.0,
                #min=0, soft_min=0,
                #max=1, soft_max=1,
                description="Scale, in XY")
    clelia_u : IntProperty(name="u",
                default=1,
                min=1, soft_min=1,
                #max=1, soft_max=1,
                description="u")
    clelia_v : IntProperty(name="v",
                default=1,
                min=1, soft_min=1,
                #max=1, soft_max=1,
                description="v")
    clelia_rounds : IntProperty(name="Rounds",
                default=1,
                min=1, soft_min=1,
                #max=1, soft_max=1,
                description="Rounds")

    ##### DRAW #####
    def draw(self, context):
        layout = self.layout

        # general options
        layout.label(text="Clelia Parameters:")

        # Parameters
        box = layout.box()
        box.prop(self, 'clelia_res')
        box.prop(self, 'clelia_w')
        box.prop(self, 'clelia_h')
        box.prop(self, 'clelia_p')
        box.prop(self, 'clelia_q')
        box.prop(self, 'options_plus')
        if self.options_plus:
            box.prop(self, 'clelia_u')
            box.prop(self, 'clelia_v')
            box.prop(self, 'clelia_rounds')

        # surface Options
        col = layout.column()
        col.label(text="Geometry Options:")
        box = layout.box()
        box.prop(self, 'geo_surf')
        if self.geo_surf:
            box.prop(self, 'geo_bDepth')
            box.prop(self, 'geo_bRes')
            box.prop(self, 'geo_extrude')
            box.prop(self, 'geo_res')

        col = layout.column()
        col.prop(self, 'location')
        col.prop(self, 'rotation')

    ##### POLL #####
    @classmethod
    def poll(cls, context):
        return context.scene != None

    ##### EXECUTE #####
    def execute(self, context):

        create_clelia_knot(self, context)

        return {'FINISHED'}