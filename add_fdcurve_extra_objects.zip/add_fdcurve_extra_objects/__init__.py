# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####
# Contributed to by:
# Pontiac, Fourmadmen, varkenvarken, tuga3d, meta-androcto, metalliandy     #
# dreampainter, cotejrp1, liero, Kayo Phoenix, sugiany, dommetysk, Jambay   #
# Phymec, Anthony D'Agostino, Pablo Vazquez, Richard Wilks, lijenstina,     #
# Sjaak-de-Draak, Phil Cote, cotejrp1, xyz presets by elfnor, revolt_randy, #


bl_info = {
    "name": "Fluid Designer Maths Functions",
    "author": "testscreenings + fluiddesigner + Multiple Authors",
    "version": (1, 0, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Add > Curve",
    "description": "Add extra parametric curve object types",
    "warning": "",
    "wiki_url": "https://www.fluiddesigner.co.uk/",
    "category": "Add Curve"
}


if "bpy" in locals():
    import importlib
    importlib.reload(add_curve_basin)
    importlib.reload(add_curve_borromean)
    importlib.reload(add_curve_capareda)
    importlib.reload(add_curve_clelia)
    importlib.reload(add_curve_enneper)
    importlib.reload(add_curve_lissajous)
    importlib.reload(add_curve_pappus)
    importlib.reload(add_curve_tennisseam)
    importlib.reload(add_curve_viviani)
    importlib.reload(add_curve_wiredish)

else:
    from . import add_curve_basin
    from . import add_curve_borromean
    from . import add_curve_capareda
    from . import add_curve_clelia
    from . import add_curve_enneper
    from . import add_curve_lissajous
    from . import add_curve_pappus
    from . import add_curve_tennisseam
    from . import add_curve_viviani
    from . import add_curve_wiredish

import bpy
from bpy.types import Menu


class VIEW3D_MT_fdcurve_maths_add(Menu):
    # Define the "Math Function" menu
    bl_idname = "VIEW3D_MT_fdcurve_maths_add"
    bl_label = "FD Parametric Curves"

    def draw(self, context):
        layout = self.layout
        layout.operator_context = 'INVOKE_REGION_WIN'
        self.layout.operator("curve.basin", text="Basin Curve", icon="CURVE_DATA")
        self.layout.operator("curve.borromean", text="Borromean Curve", icon="CURVE_DATA")
        self.layout.operator("curve.capareda", text="Capareda Curve", icon="CURVE_DATA")
        self.layout.operator("curve.clelia", text="Clelia Curve", icon="CURVE_DATA")
        self.layout.operator("curve.enneper", text="Enneper Curve", icon="CURVE_DATA")
        self.layout.operator("curve.lissajous", text="Lissajous Curve", icon="CURVE_DATA")
        self.layout.operator("curve.pappus", text="Pappus Curve", icon="CURVE_DATA")
        self.layout.operator("curve.tennisseam", text="TennisSeam Curve", icon="CURVE_DATA")
        self.layout.operator("curve.viviani", text="Viviani Curve", icon="CURVE_DATA")
        self.layout.operator("curve.wiredish", text="WireDish Curve", icon="CURVE_DATA")


class VIEW3D_MT_curve_extras_add(Menu):
    # Define the "Extra Objects" menu
    bl_idname = "VIEW3D_MT_curve_extras_add"
    bl_label = "Extras"

    def draw(self, context):
        layout = self.layout
        layout.operator_context = 'INVOKE_REGION_WIN'

# Register all operators and panels

# Define "Extras" menu
def menu_func(self, context):
    lay_out = self.layout
    lay_out.operator_context = 'INVOKE_REGION_WIN'

    lay_out.separator()
    lay_out.menu("VIEW3D_MT_fdcurve_maths_add",
                text="FD Parametric Curves", icon="PACKAGE")

# Register
classes = [
    VIEW3D_MT_fdcurve_maths_add,
    add_curve_basin.BASIN_OT_basin,
    add_curve_borromean.BORROMEAN_OT_borromean,
    add_curve_capareda.CAPAREDA_OT_capareda,
    add_curve_clelia.CLELIA_OT_clelia,
    add_curve_enneper.ENNEPER_OT_enneper,
    add_curve_lissajous.LISSAJOUS_OT_lissajous,
    add_curve_pappus.PAPPUS_OT_pappus,
    add_curve_tennisseam.TENNISSEAM_OT_tennisseam,
    add_curve_viviani.VIVIANI_OT_viviani,
    add_curve_wiredish.WIREDISH_OT_wiredish,
]

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

    # Add "Extras" menu to the "Add Curve" menu and context menu.
    bpy.types.VIEW3D_MT_curve_add.append(menu_func)


def unregister():
    # Remove "Extras" menu from the "Add Curve" menu and context menu.
    bpy.types.VIEW3D_MT_curve_add.remove(menu_func)
    
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)

if __name__ == "__main__":
    register()
